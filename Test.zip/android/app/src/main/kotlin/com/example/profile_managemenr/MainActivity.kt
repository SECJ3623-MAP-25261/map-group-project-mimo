package com.example.profile_managemenr

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
